from sqlalchemy.orm import DeclarativeBase
# class Base(DeclarativeBase):
#     pass

# Abstract base for ExchangeInfo
class ExchangeInfoSymbol(DeclarativeBase):
    pass

class BinanceKline(DeclarativeBase):
    pass