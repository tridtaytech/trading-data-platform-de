from sqlalchemy.orm import DeclarativeBase
class StreamKline(DeclarativeBase):
    pass

class MarkPriceUpdate(DeclarativeBase):
    pass